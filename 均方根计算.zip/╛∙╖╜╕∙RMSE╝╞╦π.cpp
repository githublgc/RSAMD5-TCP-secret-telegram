﻿// 均方根RMSE计算.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include<fstream>
#include<string>
#include<math.h>
using namespace std;

int main()
{
	int p = 119010;//结果中一共有19835个用户，每人评分6条，共119010条。
	ifstream infileresult;
	infileresult.open("result.txt");

	string s;
	double average = 49;
	double sum = 0;
	double temp = 0;
	int count = 0;
	double rate[120000];
	while (getline(infileresult, s))
	{
		int flag = s.find("|");
		if (s == "")//如果没数据就结束
			break;
		if (flag == -1)//如果有数据但没有|，说明是打分处 
		{
			count++;
			int flag1 = s.find(" ");//在打分处找空格，空格右侧是得分
			//!!!!注意 下面是要看flag1!!
			string s1 = s.substr(flag1 + 1, s.length() - flag1);//从空格位置向后两个开始，
			//读取长度为字符串长度减去空格及之前的长度
			rate[count] = stod(s1);
			//temp = sqrt((rate - average) * (rate - average));
			sum = sum + rate[count];//从1开始

		}
		if (flag != -1)
		{
			continue;//找到竖线，说明进入新用户，直接跳过这行，进入下一行
		}
	}
	temp = sum / count;//平均值
	cout << temp << endl;
	sum = 0;//sum用完 要清0！！！
	for (int i = 1; i <= count; i++)
	{
		sum += (rate[i] - temp) * (rate[i] - temp);
	}
	sum = sqrt(sum / count);//RMSE

	cout << "均方根误差RMSE为" << sum << endl;

	system("pause");
	return 0;
	
	
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
